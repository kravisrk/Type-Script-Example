export class  Employee{

    private id:number;
    private ename:string;
    private job:string;
    constructor(id:number, ename:string, job:string){
        this.id=id;
        this.ename=ename,
        this.job=job
    }

    public getDetails(){
        console.log(`ID: ${this.id}, Ename: ${this.ename}, Job: ${this.job}`);

    }

}

