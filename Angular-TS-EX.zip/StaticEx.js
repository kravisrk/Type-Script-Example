var Employee = /** @class */ (function () {
    function Employee(ename) {
        this.eid = ++Employee.id;
        this.ename = ename;
    }
    Employee.prototype.getDetails = function () {
        console.log("ID: " + this.eid + ", Ename: " + this.ename);
    };
    Employee.id = 1000;
    return Employee;
}());
var e1 = new Employee("Ravi Kumar");
e1.getDetails();
var e2 = new Employee("Kumar Ravi");
e2.getDetails();
