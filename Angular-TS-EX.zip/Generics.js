"use strict";
exports.__esModule = true;
var exployeeModule_1 = require("./exployeeModule");
//Generics:
var items = new Array(10, 20, 30);
for (var _i = 0, items_1 = items; _i < items_1.length; _i++) {
    var i = items_1[_i];
    console.log(i);
}
var employess = new Array(new exployeeModule_1.Employee(1, "Ravi", "Kumar"), new exployeeModule_1.Employee(2, "Kumar", "Ravi"));
for (var _a = 0, employess_1 = employess; _a < employess_1.length; _a++) {
    var item = employess_1[_a];
    item.getDetails();
}
