var s1=require('./source1');
console.log(s1.name);

console.log(s1.square(10));