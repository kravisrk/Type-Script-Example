console.log("welcome");
let name="Ravi Kumar";
let id=123456;
console.log(`name=${name}`);
console.log(`id= ${id}`);
//var and let scope
for(var i=0; i<=10; i++)
{
    console.log(i);
}
console.log(i); //will print i = 11
for(let j=0;j<=10;j++)
{
    console.log(j);
}
//console.log(j); will give error.

//Date Type
let d=new Date();
let msg=d.getDate()+"/"+(d.getMonth()+1)+"/"+d.getFullYear();
console.log(`Date is ${msg}`);

//Array allow to store unlimited items in a single 

var items=[];
console.log(`${typeof(items)}`);

var items2=new Array();
console.log(`${typeof(items2)}`);

var items3=[10,20,30,40];
for(var k=0;k<=items3.length;k++)
    console.log(items3[k]);
//For loops on array
var items=['one','two','three','four','five'];
console.log('convertional way');
for(let i=0; i<items.length;i++)
    console.log(items[i]);
console.log('index based loop');
for(var i in items)
    console.log(i);
console.log('items based loop');
for(let i of items)
console.log(i);


var items = [100, "Ravi", 45, true, [10, 20], function(){return "this is fucntion"}]
for ( var i in items)
console.log(i);

//JSON object
var employees =[{id:1, name:'ravi', salary:10000},
{id:1, name:'ravi', salary:10000}];
for ( let e of employees)
 console.log(`${e.id} ${e.name} ${e.salary}`);


//Javascript funtion
//Regular JS function
//fucntion Regular(){return "This is regular fucntion"};
//Regular();

var fun1=function(){console.log('This is FE(Functional Expression)')}
fun1();

<h1>Hello</h1>