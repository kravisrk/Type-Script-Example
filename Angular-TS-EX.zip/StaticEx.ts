class Employee{
    static id:number=1000;
    private eid:number;
    private ename:string;
    constructor(ename:string)
    {
        this.eid = ++ Employee.id;
        this.ename=ename;
    }

    getDetails(){
        console.log(`ID: ${this.eid}, Ename: ${this.ename}`);
    }
}

    var e1 = new Employee("Ravi Kumar");
    e1.getDetails();
    var e2=new Employee("Kumar Ravi");
    e2.getDetails();

