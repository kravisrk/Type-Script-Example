class Test{
    display(name?:string){
        if(name !=null)
            console.log(`Given Name is ${name}`);
        else
            console.log(`Name not provided ${name}`);

    }
}

var o1 =new Test();
var o2= new Test();

o1.display();
o2.display("Ravi");