import {Employee} from "./exployeeModule";

//Generics:
let items=new Array<number>(10,20,30);
for(let i of items)
    console.log(i);

    let employess=new Array<Employee>(
        new Employee(1, "Ravi","Kumar"),
        new Employee(2, "Kumar","Ravi")
    );

    for(let item of employess)
        item.getDetails();