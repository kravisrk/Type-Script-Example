"use strict";
exports.__esModule = true;
var Employee = /** @class */ (function () {
    function Employee(id, ename, job) {
        this.id = id;
        this.ename = ename,
            this.job = job;
    }
    Employee.prototype.getDetails = function () {
        console.log("ID: " + this.id + ", Ename: " + this.ename + ", Job: " + this.job);
    };
    return Employee;
}());
exports.Employee = Employee;
