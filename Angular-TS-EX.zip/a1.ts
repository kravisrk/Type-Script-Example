import {Employee} from './exployeeModule';

var e1=new Employee();

e1.setDetails(1,'Ravi', 'SSE');
e1.getDetails();




