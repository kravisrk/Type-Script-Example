class BankAccount{
private accountBalance:number;
constructor(name:string){
    console.log(`Hello ${name} Your account created successfully at${ new Date()}`);
    this.accountBalance=0;
    let d=new Date();
    if(d.getDay() ==0 || d.getDay() == 6)
    {
        this.accountBalance=100;
        console.log(`You got holiday promo `);
    }
    else if(d.getDay() ==1)
    {
        this.accountBalance=50;
        console.log(``);
    }
    else
        this.accountBalance=0;
}

showBalance(){
    console.log(`Account balance is:${this.accountBalance}`);
    }

DepositAmount(amount:number)
{
    if(new Date().getHours() >16 && new Date().getHours() < 17)
    {
    if(amount >= 10000)
    {

        console.log(`As per Modi instruction cant deposit more than ${amount}`);
    }
            else
            {
                console.log(`Attempt: Deposit amount of Rs${amount}`);
                this.accountBalance+=amount;
                console.log(`Status: Amount ${amount} successfully deposited`);
            }
        }
        else
        {

            console.log(`Can't deposite now. Sorry!!! we are on vacation`);
        }
    }
}

let c1= new BankAccount("Ravi Kumar Koram");
c1.showBalance();
c1.DepositAmount(100000);
c1.showBalance();
c1.DepositAmount(2000);
c1.showBalance();
