module.exports.name="Ravi";

module.exports.square=function(n){return (n*n);}