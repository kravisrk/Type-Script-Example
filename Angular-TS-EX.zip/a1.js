var Employee = /** @class */ (function () {
    function Employee() {
    }
    Employee.prototype.display = function () {
        console.log("Welcome to employee display");
        ;
    };
    return Employee;
}());
var Employee1 = /** @class */ (function () {
    function Employee1() {
    }
    Employee1.prototype.setDetails = function (id, ename, job) {
        this.id = id;
        this.ename = ename,
            this.job = job;
    };
    Employee1.prototype.getDetails = function () {
        console.log("ID: " + this.id + ", Ename: " + this.ename + ", Job: " + this.job);
    };
    return Employee1;
}());
var e = new Employee();
e.display();
var e1 = new Employee1();
e1.setDetails(10, "Ravi", "SSE");
e1.getDetails();
